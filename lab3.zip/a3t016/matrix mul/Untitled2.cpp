#include<stdio.h>
#include<conio.h>
int fact(int);
void main(){
	int n.z;
	printf("enter n");
	scanf ("%d",&n);
	z=fact(n);
}
